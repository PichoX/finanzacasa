"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Home } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function ClientPage() {
  useEffect(() => {
    // Asegurarse de que el formulario tenga la fecha actual al cargar
    const dateInput = document.getElementById("payment-date") as HTMLInputElement
    if (dateInput) {
      dateInput.valueAsDate = new Date()
    }

    // Establecer el valor predeterminado del monto
    const amountInput = document.getElementById("payment-amount") as HTMLInputElement
    if (amountInput) {
      amountInput.value = "500000"
    }

    // Manejar el envío del formulario
    const form = document.getElementById("payment-form")
    if (form) {
      form.addEventListener("submit", handleSubmit)
    }

    // Cargar y mostrar los datos existentes
    loadAndDisplayData()

    return () => {
      // Limpiar event listeners
      if (form) {
        form.removeEventListener("submit", handleSubmit)
      }
    }
  }, [])

  function handleSubmit(e: Event) {
    e.preventDefault()

    const dateInput = document.getElementById("payment-date") as HTMLInputElement
    const amountInput = document.getElementById("payment-amount") as HTMLInputElement
    const descriptionInput = document.getElementById("payment-description") as HTMLInputElement

    if (!dateInput || !amountInput) return

    const fecha = dateInput.value
    const monto = Number.parseInt(amountInput.value)
    const descripcion = descriptionInput ? descriptionInput.value : ""

    // Agregar el pago
    const pagos = JSON.parse(localStorage.getItem("pagos") || "[]")
    const id = Date.now()

    pagos.push({
      id,
      fecha,
      monto,
      descripcion,
    })

    // Guardar en localStorage
    localStorage.setItem("pagos", JSON.stringify(pagos))

    // Actualizar UI
    loadAndDisplayData()

    // Resetear formulario
    const form = e.target as HTMLFormElement
    form.reset()
    dateInput.valueAsDate = new Date()
    amountInput.value = "500000"
  }

  function loadAndDisplayData() {
    const pagos = JSON.parse(localStorage.getItem("pagos") || "[]")

    // Constantes
    const TOTAL_CUOTAS = 50
    const VALOR_CUOTA = 500000
    const TOTAL_PAGAR = TOTAL_CUOTAS * VALOR_CUOTA

    // Actualizar resumen
    const totalPagado = pagos.reduce((sum: number, pago: any) => sum + pago.monto, 0)
    const cuotasPagadas = Math.floor(totalPagado / VALOR_CUOTA)
    const saldoPendiente = TOTAL_PAGAR - totalPagado
    const porcentajeProgreso = (totalPagado / TOTAL_PAGAR) * 100

    // Formatear moneda
    const formatCurrency = (amount: number) => {
      return new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(amount)
    }

    // Formatear fecha
    const formatDate = (dateString: string) => {
      const date = new Date(dateString)
      return date.toLocaleDateString("es-CO")
    }

    // Actualizar elementos del DOM
    const totalPagadoElement = document.getElementById("total-pagado")
    const cuotasPagadasElement = document.getElementById("cuotas-pagadas")
    const saldoPendienteElement = document.getElementById("saldo-pendiente")
    const porcentajeProgresoElement = document.getElementById("porcentaje-progreso")
    const barraProgresoElement = document.getElementById("barra-progreso")

    if (totalPagadoElement) totalPagadoElement.textContent = formatCurrency(totalPagado)
    if (cuotasPagadasElement) cuotasPagadasElement.textContent = `${cuotasPagadas} / ${TOTAL_CUOTAS}`
    if (saldoPendienteElement) saldoPendienteElement.textContent = formatCurrency(saldoPendiente)
    if (porcentajeProgresoElement) porcentajeProgresoElement.textContent = `${porcentajeProgreso.toFixed(1)}%`
    if (barraProgresoElement) barraProgresoElement.style.width = `${porcentajeProgreso}%`

    // Actualizar tabla de pagos
    const paymentsTableBody = document.getElementById("payments-table-body")
    if (paymentsTableBody) {
      if (pagos.length === 0) {
        paymentsTableBody.innerHTML = `
          <tr class="text-center">
            <td colspan="4" class="py-4 text-muted-foreground">No hay pagos registrados</td>
          </tr>
        `
      } else {
        // Ordenar pagos por fecha (más reciente primero)
        const pagosSorted = [...pagos].sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())

        // Mostrar solo los últimos 5 pagos
        const pagosToShow = pagosSorted.slice(0, 5)

        paymentsTableBody.innerHTML = pagosToShow
          .map(
            (pago: any) => `
          <tr class="border-b" data-index="${pago.id}">
            <td class="px-4 py-2">${formatDate(pago.fecha)}</td>
            <td class="px-4 py-2">${formatCurrency(pago.monto)}</td>
            <td class="px-4 py-2">${pago.descripcion || "-"}</td>
            <td class="px-4 py-2">
              <button class="delete-payment text-red-500 hover:text-red-700" data-id="${pago.id}">
                Eliminar
              </button>
            </td>
          </tr>
        `,
          )
          .join("")

        // Agregar event listeners a los botones de eliminar
        document.querySelectorAll(".delete-payment").forEach((button) => {
          button.addEventListener("click", function (this: HTMLElement) {
            const id = Number.parseInt(this.getAttribute("data-id") || "0")
            eliminarPago(id)
          })
        })
      }
    }
  }

  function eliminarPago(id: number) {
    if (confirm("¿Estás seguro de que deseas eliminar este pago?")) {
      let pagos = JSON.parse(localStorage.getItem("pagos") || "[]")
      pagos = pagos.filter((pago: any) => pago.id !== id)

      // Guardar en localStorage
      localStorage.setItem("pagos", JSON.stringify(pagos))

      // Actualizar UI
      loadAndDisplayData()
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Home className="h-6 w-6" />
            <h1 className="text-xl font-bold">Control de Pagos de Vivienda</h1>
          </div>
          <nav className="flex gap-4">
            <Link href="/">
              <Button variant="ghost">Inicio</Button>
            </Link>
            <Link href="/historial">
              <Button variant="ghost">Historial</Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div className="rounded-lg border p-4">
                <h2 className="text-lg font-semibold">Resumen de Pagos</h2>
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total a pagar</p>
                    <p className="text-2xl font-bold">$25,000,000</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Pagado hasta ahora</p>
                    <p className="text-2xl font-bold" id="total-pagado">
                      $0
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Cuotas pagadas</p>
                    <p className="text-2xl font-bold" id="cuotas-pagadas">
                      0 / 50
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Saldo pendiente</p>
                    <p className="text-2xl font-bold" id="saldo-pendiente">
                      $25,000,000
                    </p>
                  </div>
                </div>
              </div>
              <div className="rounded-lg border p-4">
                <h2 className="text-lg font-semibold">Progreso</h2>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Progreso de pago</span>
                    <span className="text-sm font-medium" id="porcentaje-progreso">
                      0%
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-muted">
                    <div className="h-2 rounded-full bg-primary" id="barra-progreso" style={{ width: "0%" }}></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="rounded-lg border p-4">
              <h2 className="text-lg font-semibold">Registrar Pago</h2>
              <form id="payment-form" className="mt-4 space-y-4">
                <div className="space-y-2">
                  <label htmlFor="payment-date" className="text-sm font-medium">
                    Fecha de pago
                  </label>
                  <input
                    id="payment-date"
                    type="date"
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="payment-amount" className="text-sm font-medium">
                    Monto (COP)
                  </label>
                  <input
                    id="payment-amount"
                    type="number"
                    defaultValue="500000"
                    min="1"
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="payment-description" className="text-sm font-medium">
                    Descripción (opcional)
                  </label>
                  <input
                    id="payment-description"
                    type="text"
                    placeholder="Ej: Cuota #1"
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                  />
                </div>
                <Button type="submit" className="w-full">
                  Registrar Pago
                </Button>
              </form>
            </div>
          </div>
          <div className="mt-6 rounded-lg border p-4">
            <h2 className="text-lg font-semibold">Últimos Pagos</h2>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full table-auto">
                <thead>
                  <tr className="border-b">
                    <th className="px-4 py-2 text-left">Fecha</th>
                    <th className="px-4 py-2 text-left">Monto</th>
                    <th className="px-4 py-2 text-left">Descripción</th>
                    <th className="px-4 py-2 text-left">Acciones</th>
                  </tr>
                </thead>
                <tbody id="payments-table-body">
                  <tr className="text-center">
                    <td colSpan={4} className="py-4 text-muted-foreground">
                      No hay pagos registrados
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-4">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Control de Pagos de Vivienda
          </p>
        </div>
      </footer>
    </div>
  )
}

