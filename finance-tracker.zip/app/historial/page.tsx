"use client"

import { useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Home } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function HistorialPage() {
  useEffect(() => {
    // Cargar y mostrar los datos existentes
    loadAndDisplayData()
  }, [])

  function loadAndDisplayData() {
    const pagos = JSON.parse(localStorage.getItem("pagos") || "[]")

    // Formatear moneda
    const formatCurrency = (amount: number) => {
      return new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(amount)
    }

    // Formatear fecha
    const formatDate = (dateString: string) => {
      const date = new Date(dateString)
      return date.toLocaleDateString("es-CO")
    }

    // Actualizar tabla de pagos
    const historyTableBody = document.getElementById("history-table-body")
    if (historyTableBody) {
      if (pagos.length === 0) {
        historyTableBody.innerHTML = `
          <tr class="text-center">
            <td colspan="4" class="py-4 text-muted-foreground">No hay pagos registrados</td>
          </tr>
        `
      } else {
        // Ordenar pagos por fecha (más reciente primero)
        const pagosSorted = [...pagos].sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())

        historyTableBody.innerHTML = pagosSorted
          .map(
            (pago: any) => `
          <tr class="border-b" data-index="${pago.id}">
            <td class="px-4 py-2">${formatDate(pago.fecha)}</td>
            <td class="px-4 py-2">${formatCurrency(pago.monto)}</td>
            <td class="px-4 py-2">${pago.descripcion || "-"}</td>
            <td class="px-4 py-2">
              <button class="delete-payment text-red-500 hover:text-red-700" data-id="${pago.id}">
                Eliminar
              </button>
            </td>
          </tr>
        `,
          )
          .join("")

        // Agregar event listeners a los botones de eliminar
        document.querySelectorAll(".delete-payment").forEach((button) => {
          button.addEventListener("click", function (this: HTMLElement) {
            const id = Number.parseInt(this.getAttribute("data-id") || "0")
            eliminarPago(id)
          })
        })
      }
    }
  }

  function eliminarPago(id: number) {
    if (confirm("¿Estás seguro de que deseas eliminar este pago?")) {
      let pagos = JSON.parse(localStorage.getItem("pagos") || "[]")
      pagos = pagos.filter((pago: any) => pago.id !== id)

      // Guardar en localStorage
      localStorage.setItem("pagos", JSON.stringify(pagos))

      // Actualizar UI
      loadAndDisplayData()
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Home className="h-6 w-6" />
            <h1 className="text-xl font-bold">Control de Pagos de Vivienda</h1>
          </div>
          <nav className="flex gap-4">
            <Link href="/">
              <Button variant="ghost">Inicio</Button>
            </Link>
            <Link href="/historial">
              <Button variant="ghost">Historial</Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-6">
          <div className="mb-6 flex items-center gap-2">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h2 className="text-2xl font-bold">Historial de Pagos</h2>
          </div>
          <div className="rounded-lg border p-4">
            <div className="overflow-x-auto">
              <table className="w-full table-auto">
                <thead>
                  <tr className="border-b">
                    <th className="px-4 py-2 text-left">Fecha</th>
                    <th className="px-4 py-2 text-left">Monto</th>
                    <th className="px-4 py-2 text-left">Descripción</th>
                    <th className="px-4 py-2 text-left">Acciones</th>
                  </tr>
                </thead>
                <tbody id="history-table-body">
                  <tr className="text-center">
                    <td colSpan={4} className="py-4 text-muted-foreground">
                      No hay pagos registrados
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-4">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Control de Pagos de Vivienda
          </p>
        </div>
      </footer>
    </div>
  )
}

