import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import type { Metadata } from "next"

import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Control de Pagos de Vivienda",
  description: "Aplicación para controlar los pagos de tu casa",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
        <script
          dangerouslySetInnerHTML={{
            __html: `
      document.addEventListener('DOMContentLoaded', function() {
        // Constantes
        const TOTAL_CUOTAS = 50;
        const VALOR_CUOTA = 500000;
        const TOTAL_PAGAR = TOTAL_CUOTAS * VALOR_CUOTA;
        
        // Elementos del DOM
        const paymentForm = document.getElementById('payment-form');
        const paymentsTableBody = document.getElementById('payments-table-body');
        const historyTableBody = document.getElementById('history-table-body');
        
        // Elementos de resumen
        const totalPagadoElement = document.getElementById('total-pagado');
        const cuotasPagadasElement = document.getElementById('cuotas-pagadas');
        const saldoPendienteElement = document.getElementById('saldo-pendiente');
        const porcentajeProgresoElement = document.getElementById('porcentaje-progreso');
        const barraProgresoElement = document.getElementById('barra-progreso');
        
        // Cargar pagos desde localStorage
        let pagos = JSON.parse(localStorage.getItem('pagos') || '[]');
        
        // Formatear números como moneda colombiana
        function formatCurrency(amount) {
          return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
          }).format(amount);
        }
        
        // Formatear fecha
        function formatDate(dateString) {
          const date = new Date(dateString);
          return date.toLocaleDateString('es-CO');
        }
        
        // Actualizar resumen de pagos
        function actualizarResumen() {
          const totalPagado = pagos.reduce((sum, pago) => sum + pago.monto, 0);
          const cuotasPagadas = Math.floor(totalPagado / VALOR_CUOTA);
          const saldoPendiente = TOTAL_PAGAR - totalPagado;
          const porcentajeProgreso = (totalPagado / TOTAL_PAGAR) * 100;
          
          if (totalPagadoElement) totalPagadoElement.textContent = formatCurrency(totalPagado);
          if (cuotasPagadasElement) cuotasPagadasElement.textContent = \`\${cuotasPagadas} / \${TOTAL_CUOTAS}\`;
          if (saldoPendienteElement) saldoPendienteElement.textContent = formatCurrency(saldoPendiente);
          if (porcentajeProgresoElement) porcentajeProgresoElement.textContent = \`\${porcentajeProgreso.toFixed(1)}%\`;
          if (barraProgresoElement) barraProgresoElement.style.width = \`\${porcentajeProgreso}%\`;
        }
        
        // Renderizar tabla de pagos
        function renderizarTablaPagos(tableBody) {
          if (!tableBody) return;
          
          if (pagos.length === 0) {
            tableBody.innerHTML = \`
              <tr class="text-center">
                <td colspan="4" class="py-4 text-muted-foreground">No hay pagos registrados</td>
              </tr>
            \`;
            return;
          }
          
          // Ordenar pagos por fecha (más reciente primero)
          const pagosSorted = [...pagos].sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
          
          // Limitar a los últimos 5 pagos para la tabla de la página principal
          const pagosToShow = tableBody.id === 'payments-table-body' ? pagosSorted.slice(0, 5) : pagosSorted;
          
          tableBody.innerHTML = pagosToShow.map((pago, index) => \`
            <tr class="border-b" data-index="\${pago.id}">
              <td class="px-4 py-2">\${formatDate(pago.fecha)}</td>
              <td class="px-4 py-2">\${formatCurrency(pago.monto)}</td>
              <td class="px-4 py-2">\${pago.descripcion || '-'}</td>
              <td class="px-4 py-2">
                <button class="delete-payment text-red-500 hover:text-red-700" data-id="\${pago.id}">
                  Eliminar
                </button>
              </td>
            </tr>
          \`).join('');
          
          // Agregar event listeners a los botones de eliminar
          document.querySelectorAll('.delete-payment').forEach(button => {
            button.addEventListener('click', function() {
              const id = parseInt(this.getAttribute('data-id'));
              eliminarPago(id);
            });
          });
        }
        
        // Agregar un nuevo pago
        function agregarPago(fecha, monto, descripcion) {
          const id = Date.now(); // Usar timestamp como ID único
          pagos.push({
            id,
            fecha,
            monto: parseInt(monto),
            descripcion
          });
          
          // Guardar en localStorage
          localStorage.setItem('pagos', JSON.stringify(pagos));
          
          // Actualizar UI
          actualizarResumen();
          renderizarTablaPagos(paymentsTableBody);
          renderizarTablaPagos(historyTableBody);
        }
        
        // Eliminar un pago
        function eliminarPago(id) {
          if (confirm('¿Estás seguro de que deseas eliminar este pago?')) {
            pagos = pagos.filter(pago => pago.id !== id);
            
            // Guardar en localStorage
            localStorage.setItem('pagos', JSON.stringify(pagos));
            
            // Actualizar UI
            actualizarResumen();
            renderizarTablaPagos(paymentsTableBody);
            renderizarTablaPagos(historyTableBody);
          }
        }
        
        // Event listener para el formulario de pago
        if (paymentForm) {
          paymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const fecha = document.getElementById('payment-date').value;
            const monto = document.getElementById('payment-amount').value;
            const descripcion = document.getElementById('payment-description').value;
            
            agregarPago(fecha, monto, descripcion);
            
            // Resetear formulario
            this.reset();
            document.getElementById('payment-date').valueAsDate = new Date();
            document.getElementById('payment-amount').value = VALOR_CUOTA;
          });
        }
        
        // Inicializar la fecha actual en el formulario
        if (document.getElementById('payment-date')) {
          document.getElementById('payment-date').valueAsDate = new Date();
        }
        
        // Inicializar la aplicación
        actualizarResumen();
        renderizarTablaPagos(paymentsTableBody);
        renderizarTablaPagos(historyTableBody);
      });
    `,
          }}
        />
      </body>
    </html>
  )
}



import './globals.css'