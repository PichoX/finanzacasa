import type { Metadata } from "next"
import ClientPage from "./clientpage"

export const metadata: Metadata = {
  title: "Control de Pagos de Vivienda",
  description: "Aplicación para controlar los pagos de tu casa",
}

export default function Page() {
  return <ClientPage />
}

